api_token = 'Insert your API token'

username = 'email address sending the message'
password = 'email password'
